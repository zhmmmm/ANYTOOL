#include "OpenGL_AY_Engine.h"
#include "Textures.h"

//=====================================================================Texture2D
Texture2D::Texture2D()
{

}














//=====================================================================Texture3D
Texture3D::Texture3D()
{

}
