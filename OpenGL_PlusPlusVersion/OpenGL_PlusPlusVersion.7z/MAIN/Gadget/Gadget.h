#pragma once
#include "../OpenGL_AY_Engine.h"

class Gadget
{
public:
	static void CreateQuadrangle2D();
	static void CreateQuadrangle3D();


};