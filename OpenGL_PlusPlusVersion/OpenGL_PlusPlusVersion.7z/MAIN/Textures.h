#pragma once
#include "OpenGL_AY_Engine.h"

class Texture2D
{
public:
	Texture2D();
};

class Texture3D
{
public:
	Texture3D();
};